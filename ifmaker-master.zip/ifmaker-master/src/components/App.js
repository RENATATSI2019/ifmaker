import React from 'react';
import './App.css';
import Rotas from '../Rotas'

const App = () => <Rotas />

export default App;
